﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    //class for base 64 file
    public class Base64
    {
        public string base64
        { get; set; }
    }
}
